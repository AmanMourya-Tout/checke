 <?php
// Include the Stripe PHP library
require_once('vendor/autoload.php'); // Adjust the path as needed

// Set your Stripe API keys
$stripeSecretKey = 'sk_test_51NdabBSCJaXSDjT1vRZK9v3OfaM5UHQpE4xEv0OI8vjA87gaX4as60FMh1kOsf71Uh4iMDSvVKwR6GFbXByemB2t00FW3HPaf5 ';
$stripePublicKey = 'pk_test_51NdabBSCJaXSDjT1y8ZRWK9AHAUUMMb0IwtPGkPYodBFaZEsdWMMaPyQiDXQHF17zhY2FlI8jemO38nIUtkFUjR100CfKd16aJ';

\Stripe\Stripe::setApiKey($stripeSecretKey);

// Process the payment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['stripeToken'];
    try {
        $paymentIntent = \Stripe\PaymentIntent::create([
            'amount' => 1000, 
            'currency' => 'usd', 
         
        ]);

        // Handle the response from the API
        // ...
    } catch (\Stripe\Exception\ApiErrorException $e) {
        // Handle the API error
        echo 'Error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Stripe Payment Example</title>
    <script src="https://js.stripe.com/v3/"></script>
</head>
<body>
    <h1>Make a Payment</h1>
    <form method="post">
        <script
            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
            data-key="<?php echo $stripePublicKey; ?>"
            data-amount="1000" <!-- Amount in cents -->
            data-name="Stripe Payment Example"
            data-description="Test Payment"
            data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
            data-locale="auto"
            data-currency="usd">
        </script>
    </form>
</body>
</html>
 